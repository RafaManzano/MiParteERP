﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoERP_API_DAL.Lists
{
    class Class1
    {
        #region"Atributos privados"
        #endregion

        #region"Constructor"
        #endregion

        #region"Propiedades públicas"
        #endregion
    }
}
